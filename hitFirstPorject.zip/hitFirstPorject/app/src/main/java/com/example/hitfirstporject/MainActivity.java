package com.example.hitfirstporject;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private TextView result;
    double firstNum;
    double secondNum;
    char ch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        result = findViewById(R.id.textViewResult);
        result.setText("");
    }

    public void numFun(View view) {

        Button button = (Button) view;
        result.append(button.getText().toString());

    }

    public void actionFun(View view) {

         ch= ((Button) view).getText().toString().charAt(0);
        firstNum = Double.parseDouble(result.getText().toString());
        result.setText("");

    }

    public void equalFun(View view) {
        try {

            secondNum = Double.parseDouble(result.getText().toString());

            double calculationResult = 0;


            switch (ch) {
                case '+':
                    calculationResult = firstNum + secondNum;
                    break;
                case '-':
                    calculationResult = firstNum - secondNum;
                    break;
                case '*':
                    calculationResult = firstNum * secondNum;
                    break;
                case '/':
                    if (secondNum != 0) {
                        calculationResult = firstNum / secondNum;
                    } else {
                        result.setText("Error: Division by 0");
                        return;
                    }
                    break;
                default:
                    result.setText("Invalid Operator");
                    return;
            }


            result.setText(String.valueOf(calculationResult));
        } catch (NumberFormatException e) {
            result.setText("Error");
        }
    }
}
